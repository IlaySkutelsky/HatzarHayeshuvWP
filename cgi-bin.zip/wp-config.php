<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/home/manaoycm/public_html/wp-content/plugins/wp-super-cache/' );
define( 'DB_NAME', 'manaoycm_wp' );

/** Database username */
define( 'DB_USER', 'manaoycm_wp' );

/** Database password */
define( 'DB_PASSWORD', 'WordPr3ss' );

/** Database hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'd6;5Pu8wE3R~@2#l|V2zJlv+02164:;]ep:-1_9mIk5]&w[l%8g]44S*4+O#~NK0');
define('SECURE_AUTH_KEY', '-U-#pU4Kk|9ZI5+Sp4DeASL-WXVVC:l)%+U02ip*G:FtSN9765@Fg3+cs])sYF8w');
define('LOGGED_IN_KEY', '+k+d5rS#yj!Fi#k;[yb0!9IU6_wT65olm0gSBvh9Lv1:p4DvU)kh#X5F1j3hq27H');
define('NONCE_KEY', 'P_Zj)Kf%+XuMM6:6T3e_*TH@nG_~%(_fja3Z/;:O408E87]!j78y_Vt0DzL(9+Az');
define('AUTH_SALT', '5t*@&Gy_N+8E*B1E6*0(6b1xor@fM3M[-W@41o_xo1Z5B5e5*r(B03VB4+5uS6(R');
define('SECURE_AUTH_SALT', 'anKqX17&tn0SVA%6J6j@FLD|0#iD6eh-0ze52P6TeH81+F8uDNT_)7yGi#BV123I');
define('LOGGED_IN_SALT', 'O7*2W@Z5+68s|5!7o]1*ZBR5aQDj0lIU0y7V2826j-;k]V1B!rOz)s9h93lk_570');
define('NONCE_SALT', 'k-;F&ML%B&)9s6O:V#@dM4(RWjgW:9:5--G0;5@b~8agn-7CbAn#ypnIGzWb[p8l');


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'QyeG85r5n_';


/* Add any custom values between this line and the "stop editing" line. */

define('WP_ALLOW_MULTISITE', true);
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
